@echo off
title AI Java Interview - Running
cd /d "C:\Syshealth\syshealth_code\bsm-sysh\Sysjavacode\"
echo.
echo  ============================================================
echo   AI Java Interview Assistant - Starting...
echo   URL: http://localhost:8501/JavaAIMockInterview/
echo  ============================================================
echo.

set PYTHON=C:\Users\aswain2\AppData\Local\Programs\Python\Python313\python.exe

:: Verify Python exists
if not exist "%PYTHON%" (
    echo [ERROR] Python not found at %PYTHON%
    echo Please run install.bat first.
    pause
    exit /b 1
)

:: Start Streamlit server
start "AI Java Interview Server" "%PYTHON%" -m streamlit run ai_assistant.py ^
    --server.port 8501 ^
    --server.baseUrlPath "/JavaAIMockInterview" ^
    --server.headless false ^
    --browser.gatherUsageStats false

echo  Server starting... waiting 8 seconds...
timeout /t 8 /nobreak >nul

:: Open browser
start "" "http://localhost:8501/JavaAIMockInterview/"

echo  App launched! Browser should open automatically.
echo  Press any key to close this window (server keeps running).
pause >nul
